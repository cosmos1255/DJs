const mongoose = require('mongoose');

// connect to mongo database
mongoose.connect('mongodb+srv://group3_0:group3cop4331@cluster0-2n09e.mongodb.net/test?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true }, (err) => 
{
    if (!err)
    {
        console.log('MongoDB Connection Succeeded.')
    }
    else
    {
        console.log('Error in DB connection : ' + err)
    }
});

require('./contact');
