// A contact schema
var mongoose = require('mongoose');

// our model or schema for our users in the database
var ContactSchema = new mongoose.Schema({
    // temporary schema
    name:
    {
        type: String,
        required: true
    },
    email:
    {
        type: String,
        required: true
    },
    gender: String,
    phone: String,
    create_date:
    {
        type: Date,
        default: Date.now
    }
});

// exports the schema as a module
var Contact = module.exports = mongoose.model('Contact', ContactSchema, 'smallProject.contactLists');


// The real schema
/*
id: String,
    username: String,
    password: String,
    create_date: {
        type: Date,
        default: Date.now
    },
    contact: [
    {
        name: String,
        addresss: String,
        phone: String,
        city: String,
    }]
*/
