// More info about express functions
// https://expressjs.com/en/api.html#res.redirect


// Dependency
var express = require('express');
// Initialize express router
var router = express.Router();

// Import contact controller
var contactController = require('../controllers/contactController');

// Set default API response
router.get('/', function (req, res) {
    res.json({
    status: "API WORKING",
    message: "HERE IS THE API MESSAGE"
    });
});

// Contact routes
router.route('/contacts')
    .get(contactController.index)
    .put(contactController.new);

router.route('/contacts/:contact_id')
    .get(contactController.view)
    .patch(contactController.update)
    .put(contactController.update)
    .delete(contactController.delete);

// export router as a module
module.exports = router;
