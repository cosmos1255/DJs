// our dependencies, creates a router
var express = require('express');
var router = express.Router();

// require contact Controller
var contact = require('../controllers/contactController');

// Get all contacts
// goes to the contact.list function from contactController.js
router.get('/', contact.list);

// Get single contact by id
router.get('/show/:id', contact.show);

// Create contact
router.get('/create', contact.create);

// Save contact
router.post('/save', contact.save);

// Edit contact
router.get('/edit/:id', contact.edit);

// Edit update
router.post('/update/:id', contact.update);

// Delete contact
router.post('/delete/:id', contact.delete);

// export router as a module
module.exports = router;
