# Tutorials
This files contains some of the useful tutorials that we found on the web. 
Be mindful to place updated stuff that could help us to understand what we are doing to place together a MEAN/MERN stack web app.

## MongoDB
- Crash course in MongoDB: https://youtu.be/-56x56UppqQ

## Express
(I don't know how much we need to learn about this, but feel free to add one that you found useful to learn)

## Angular or React
(Still nothing great, feel free to add one that you found useful to learn)

## Node
(kind of basic, but feel free to add one that you found useful to learn)

## REST API for MongoDB
(Still nothing great, feel free to add one that you found useful to learn)

## Deploy Web App
-Into AWS: https://scotch.io/tutorials/deploying-a-mean-app-to-amazon-ec2-part-1